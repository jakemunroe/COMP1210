/**
 * Demonstrates the difference between print and println.
 */
public class CountOff
{
/**
 *  Prints down the page then across.
 *    @param args - Standard commandline arguments (not used)
 */
   public static void main(String[] args)
   {
      System.out.println("Down");
      System.out.println("One... ");
      System.out.println("Two... ");
      System.out.println("Three... ");
      System.out.print("Across... ");
      System.out.print("four... ");
      System.out.print("five... ");
      System.out.println("and end"); 
   }
}