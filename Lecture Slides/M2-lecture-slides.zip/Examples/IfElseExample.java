public class IfElseExample
{
   public static void main(String[] args)
   {
      int num1 = 9, num2 = 7;
      if (num1 < num2) {
         System.out.println(num1 + " is < " + num2);
      }
      else {
         System.out.println(num1 + " is >= " + num2);
      }
      System.out.println("Done!");
   }
}