public class IfExample2
{
   public static void main(String[] args)
   {
      int temp = 39;
      boolean isCold = temp < 50;
      if (isCold) {
         System.out.println("It's cold!"); 
      }
      System.out.println("Temp = " + temp); 
   
   }
}